#include "playerManagement.h"

/*
Inicializa a estrutura de um novo jogador
player_fd: return do accept deste novo jogador
*/
void initializeNewPlayer(playerStruct *newPlayer,int player_fd, int playerNumber)
{
  newPlayer->player_fd = player_fd;
  newPlayer->playerNumber = playerNumber;
  //Fazer a parte de dar cores aos jogadores
  newPlayer->color = 1;
  newPlayer->score = 0;
}
