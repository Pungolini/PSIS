#ifndef UI_LIBRARY_H
#define UI_LIBRARY_H


#include <SDL2/SDL.h>
#include <SDL2/SDL_ttf.h>

#define NCOLORS 8
#define DEFAULT 1
#define WIDTH 600
#define HEIGHT 600
#define DELAY 1500

typedef enum cores
{
	BLACK = 0,
	WHITE = 1,
	RED = 2,
	GRAY = 3,
	GREEN = 4,
	CYAN = 5,
	LIGHT_BLUE = 6,
	BLUE = 7,
	BG = GRAY
}COLOR;

 
extern short BOARD_DIM;
extern SDL_Color  colors[NCOLORS];

void paint_default(int,int);
void write_card(int  board_x, int board_y, char * text, int r, int g, int b);
void paint_card(int  board_x, int board_y , int r, int g, int b);
void clear_card(int  board_x, int board_y);
void get_board_card(int mouse_x, int mouse_y, int * board_x, int *board_y);
int create_board_window(int width, int height,  int dim);
void close_board_windows();

#endif