//#include "server.h"

/*
player_fd: return do accept deste player
color: cor associada a este jogadores
score: numero de casas descobertas
*/

//inicializa o player
#pragma once 

typedef struct _playerStruct
{
  int player_fd;
  int color;
  int score;
  int playerNumber;
}playerStruct;

void initializeNewPlayer(playerStruct *,int,int);

#include "UI_library.h"

