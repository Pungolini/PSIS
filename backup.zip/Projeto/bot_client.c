#include "bot_client.h"



short** plays;


short** createPlaysBoard(short rows, short cols)
{
	short **plays = malloc(rows * sizeof(*plays));
	if (!plays)
	{
		puts("Erro de alocacao");
		exit(EXIT_FAILURE);
	}

	for (short i = 0; i < rows; ++i)
	{
		plays[i] = malloc(cols * sizeof(**plays));
		if (!plays[i])
		{
			puts("Erro de alocacao");
			exit(EXIT_FAILURE);
		}
	}

	return plays;
}

void initPlaysBoard(short **plays,short rows, short cols)
{
	for (short i = 0; i < rows; ++i)
		for (short j = 0; j < cols; ++j)
			plays[i][j] = UNVISITED;
}

void botPlay(short rows,short cols, play_response *resp)
{
	short found = 0,r,c,firstPick = 1;
	plays = createPlaysBoard(rows,cols);
	initPlaysBoard(plays,rows,cols);

	// Obter indice da matriz
	r = random()%rows;
	c = random()%cols;
	*resp = board_play(r,c);

	
	// Verificar se jogada ja foi escolhida
	for (short i = 0; i < rows && !found; ++i)
	{
		for (short j = 0; j < cols; ++j)
		{	

			if (plays[i][j] != UNVISITED)
			{
				if ((i != r) && (j != c) && plays[i][j] == VISITED)
				{
					*resp = board_play(i,j);
					plays[i][j] = plays[r][c] = MATCHED;
					found = 1;
					break;
				}
			}
		}
	}







}