#ifndef BOT_CLIENT_H
#define BOT_CLIENT_H

#include <stdio.h>
#include <stdlib.h>

typedef enum _flags
{
	UNVISITED = -1,
	VISITED = 1,
	MATCHED = 0,

	
}BOARD_FLAGS;

#include "board_library.h"



#endif