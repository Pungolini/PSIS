#include <stdio.h>
#include <stdint.h>
#include <sys/socket.h>
#include <arpa/inet.h>
#include <stdlib.h>
#include <pthread.h>
#include <unistd.h>
#include "playerManagement.h"

#define SERVER_PORT 3000

typedef struct _pt
{
  short x,y;
}PT;


int sock_fd;

void * thread_func_send (void *arg)
{
  SDL_Event event;
  short done = 0;
  int sock_fd_server = (intptr_t)arg;
  PT playCoord;
  printf("Send Thread\n");


  while( !done)
  {
    while (SDL_PollEvent(&event))
    {
      switch (event.type)
      {
        case SDL_QUIT:
        {
          done = SDL_TRUE;
          break;
        }
        case SDL_MOUSEBUTTONDOWN:
        {
          get_board_card(event.button.x, event.button.y, &playCoord.x, &playCoord.y);

          printf("click (%d %d) -> (%d %d)\n", event.button.x, event.button.y, playCoord.x,playCoord.y);
            //Envia a estrutura deste jogador para o cliente
          send(sock_fd, &playCoord, sizeof(PT), 0);
          printf("Sent structure!!\n\n");
        }
      }
     }
   }


  return 0;
}

void* thread_func_receive (void *arg)
{
  int receivedNumber = 0;
  int sock_fd = (intptr_t)arg;
  printf("Received from thread Thread\n\n");

  while(1)
  {
    printf("While do Receive\n");
    recv(sock_fd, &receivedNumber, sizeof(receivedNumber), 0);
    printf("Received Number %d\n", receivedNumber);
    sleep(1);
  }

  return 0;
}

void makeConnection(char *address,struct sockaddr_in *server_addr)
{

    //cria a socket
  

  //Verifica a socket
  if ((sock_fd = socket(AF_INET, SOCK_STREAM, 0)) == -1)
  {
    perror("socket: ");
    exit(-1);
  }

  server_addr->sin_family = AF_INET;
  server_addr->sin_port= htons(SERVER_PORT);

  if(inet_aton(address, &(server_addr->sin_addr)) <= 0)
  { 
        puts("\nInvalid address/ Address not supported \n"); 
        exit (-1); 
  } 

  //Conecta com o server
  if(connect(sock_fd,(const struct sockaddr *) server_addr,sizeof(*server_addr)) == -1)
  {
        puts("Can't connect to the server\n");
        exit(-1);
  }

  puts("Connected to the server\n");

}




int main(int argc, char *argv[])
{
  struct sockaddr_in server_addr;
  short playerNumber = -1,done = 0;
  SDL_Event event;
  PT playCoord;


  playerStruct player;
  //threads
  pthread_t getDimThread;
  pthread_t sendThreadId;
  pthread_t receiveThreadId;

  //verifica os argumentps
  if (argc < 2)
  {
    printf("second argument should be server address\n");
    exit(-1);
  }


  // Estabelecer ligacao com o servidor
  makeConnection(argv[1],&server_addr);

  // get dim
  create_board_window(WIDTH,HEIGHT, 4);



  //Iniciar o player antes de o ler
  player.player_fd = -1;
  player.playerNumber = -1;
  player.color = -1;
  player.score = -1;

  //Le do sever o player number
  recv(sock_fd, &player, sizeof(player), 0);
  printf("\n\nEs o player %d\n", player.playerNumber);
  printf("Cor: %d\n", player.color);
  printf("Player fd: %d\n", player.player_fd);
  printf("Player Score: %d\n", player.score);





  pthread_create(&sendThreadId, NULL, thread_func_send, (void*)(intptr_t)sock_fd);
  printf("Thread do envio criada\n");
  pthread_create(&receiveThreadId, NULL, thread_func_receive, (void*)(intptr_t)sock_fd);
  printf("Thread da receção criada\n");



  pthread_join(sendThreadId, NULL);
  pthread_join(receiveThreadId, NULL);

  close(sock_fd);
}
