#include "server.h"



//Vetor de jogadores
playerStruct players[NMAX];

// Tamanho do tabuleiro
short BOARD_DIM = 0;


void* thread_func_player (void *arg)
{

  int threadNumber = (intptr_t)arg;
  int sendLoop = 0;

  printf("\nThread do player %d\n", threadNumber);
  printf("Cor na thread: %d\n", players[threadNumber].color);
  printf("PlayerNumber na thread: %d\n", players[threadNumber].playerNumber);
  printf("Player fd na thread: %d\n", players[threadNumber].player_fd);
  printf("Score na thread: %d\n", players[threadNumber].score);

  init_board(BOARD_DIM);
  puts("Board initialized!!");

  //Envia a estrutura deste jogador para o cliente
  send(players[threadNumber].player_fd, &players[threadNumber], sizeof(players[threadNumber]), 0);

  //Envia constantemente o board atualizado para o jogador
  while(1)
  {
    send(players[threadNumber].player_fd, &sendLoop, sizeof(sendLoop), 0);

    sendLoop ++;
    sleep(1);
  }

  return 0;
}

int main (int argc, char * argv[])
{


  srand(time(NULL));
  //Endereço para a thread
  struct sockaddr_in local_addr;

  int threadNumber = 0;
  int playerCounter = 0;
  int newPlayer = 0;

  //Vetor de threads
  pthread_t thread_id[NMAX];

  if (argc < 2)
  {
    printf("usage: ./server [board size (px)]\n");
    exit(-1);
  }

  //Cria a socket do SERVER_PORT
  int sock_fd = socket(AF_INET, SOCK_STREAM, 0);

  // Tamanho do tabuleiro
  BOARD_DIM = atoi(argv[1]);
  printf("BOARD_DIM MAIN = %d\n",BOARD_DIM );

  if (sock_fd == -1)
  {
    perror("socket: ");
    exit(-1);
  }

  local_addr.sin_family = AF_INET;
  local_addr.sin_port= htons(SERVER_PORT);
  local_addr.sin_addr.s_addr= INADDR_ANY;

  //Faz o bind da socket
  int err = bind(sock_fd, (struct sockaddr *)&local_addr, sizeof(local_addr));

  if(err == -1) {
    perror("bind");
    exit(-1);
  }
  printf(" socket created and binded \n");

  //faz o listen
  listen(sock_fd, 10);

  while(1)
  {
    printf("Waiting for players\n");

    //Aceita um cliente
    newPlayer = accept(sock_fd, NULL, NULL);

    // Inicializar jogador novo
    initializeNewPlayer(&players[playerCounter],newPlayer, playerCounter);

    printf("\n\nNew client connected (%d)\n", playerCounter);
    printf("fd deste player: %d\n", newPlayer);
    printf("Cor: %d\n", players[playerCounter].color);
    //passa o player number
    write(players[playerCounter].player_fd, &playerCounter, sizeof(playerCounter));

    //Cria a thread para este jogador
    pthread_create(&thread_id[playerCounter], NULL, thread_func_player, (void*)(intptr_t)playerCounter);

    




    //Incrementa o contador de jogadores
    ++playerCounter;

    //Fecha as sockets
    /*for (int i = 0; i < playerCounter; i++)
    {
      close(players[i].player_fd);
    }*/
  }
}
