

#pragma once 

#include <stdio.h>
#include <stdint.h>
#include <sys/socket.h>
#include <arpa/inet.h>
#include <stdlib.h>
#include <unistd.h>
#include <pthread.h>
#include <string.h>
#include <time.h>

#define NMAX 100
#define SERVER_PORT 3000

extern short BOARD_DIM;

#include "playerManagement.h"

